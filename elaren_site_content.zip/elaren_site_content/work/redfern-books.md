---
title: "Redfern Books"
slug: "/work/redfern-books"
summary: "Static build with ongoing updates under our Standard Plan."
---

# Redfern Books

**Challenge.** Frequent content changes with a heavy CMS.  
**Approach.** Static site with Git-based updates and preview deploys.  
**Result.** Faster publishing, lower costs, stable performance.

[Back to Work](/work)
