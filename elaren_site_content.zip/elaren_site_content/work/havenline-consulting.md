---
title: "Havenline Consulting"
slug: "/work/havenline-consulting"
summary: "A new brand presence and simplified site map."
---

# Havenline Consulting

**Challenge.** Fragmented brand and scattered pages.  
**Approach.** Tight information architecture and a calm typographic system.  
**Result.** Higher time on page and fewer support emails.

[Back to Work](/work)
