---
title: "Resources"
slug: "/resources"
description: "Guides, templates, and case notes to keep your site bright and enduring."
---

# Resources

- **Guides**
  - [Keep a Static Site Fresh](/resources/guides/keep-a-static-site-fresh)
- **Templates**
  - [Project Brief](/resources/templates/project-brief)
