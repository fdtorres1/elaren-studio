---
title: "Privacy Policy"
slug: "/privacy"
---

# Privacy Policy

We collect only the information necessary to deliver and improve our services. We do not sell your data. Contact us for any data requests.
