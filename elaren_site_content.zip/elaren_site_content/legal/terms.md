---
title: "Terms of Service"
slug: "/terms"
---

# Terms of Service

By using our site and services you agree to fair use and reasonable limitations. Scope for Care Plans is defined on the Plans page. Larger work is quoted separately.
