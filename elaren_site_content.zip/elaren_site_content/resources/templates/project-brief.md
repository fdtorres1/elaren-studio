---
title: "Project Brief"
slug: "/resources/templates/project-brief"
---

# Project Brief

**Goals**  
**Audience**  
**Key pages**  
**Brand assets** (logo, fonts, colors)  
**Examples you like** (3–5 links)  
**Timeline**  
**Success metrics**
